import contractions from './contractions/index.js'

export default { contractions }
