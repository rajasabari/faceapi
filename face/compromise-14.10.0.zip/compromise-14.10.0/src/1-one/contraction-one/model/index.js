import contractions from './contractions.js'
import numberSuffixes from './number-suffix.js'

export default {
  one: {
    contractions,
    numberSuffixes
  }
}
