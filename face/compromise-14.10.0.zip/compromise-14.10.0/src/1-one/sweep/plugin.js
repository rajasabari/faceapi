import lib from './lib.js'
import api from './api.js'
import methods from './methods/index.js'

export default {
  lib,
  api,
  methods: {
    one: methods,
  }
}