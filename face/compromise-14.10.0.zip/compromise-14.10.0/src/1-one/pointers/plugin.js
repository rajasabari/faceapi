import methods from './methods/index.js'
import api from './api/index.js'

export default {
  methods,
  api,
}
