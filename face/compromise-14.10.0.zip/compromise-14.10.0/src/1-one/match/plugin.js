import api from './api/index.js'
import methods from './methods/index.js'
import lib from './lib.js'

export default {
  api,
  methods,
  lib,
}
