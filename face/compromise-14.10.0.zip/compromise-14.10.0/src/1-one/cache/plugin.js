import methods from './methods/index.js'
import api from './api.js'
import compute from './compute.js'

export default {
  api,
  compute,
  methods,
}
