import cacheDoc from './cacheDoc.js'

export default {
  one: {
    cacheDoc,
  },
}
