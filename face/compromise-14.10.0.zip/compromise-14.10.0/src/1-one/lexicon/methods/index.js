import expandLexicon from './expand.js'

export default {
  one: {
    expandLexicon,
  }
}