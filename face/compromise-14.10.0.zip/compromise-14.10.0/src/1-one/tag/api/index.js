import tag from './tag.js'

const tagAPI = function (View) {
  Object.assign(View.prototype, tag)
}
export default tagAPI
