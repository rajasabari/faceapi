import api from './api/index.js'
import compute from './compute/index.js'

export default {
  api,
  compute,
}
