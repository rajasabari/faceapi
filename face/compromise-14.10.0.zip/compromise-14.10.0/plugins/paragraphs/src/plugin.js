import api from './api.js'

export default {
  api,
}