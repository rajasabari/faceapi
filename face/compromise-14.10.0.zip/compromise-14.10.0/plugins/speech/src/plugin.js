import compute from './compute/index.js'
import api from './api.js'

export default {
  api,
  compute
}