import soundsLike from './soundsLike/index.js'
import syllables from './syllables/index.js'

export default {
  soundsLike,
  syllables
}