import workerPool from './index.js'

export default {
  lib: {
    workerPool
  }
}
