import lazy from './lazyParse.js'

export default {
  lib: {
    lazy
  }
}