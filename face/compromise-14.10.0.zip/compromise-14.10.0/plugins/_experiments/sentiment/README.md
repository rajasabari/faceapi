experimental rule-based, compressed-data sentiment analysis by Scott Cram
