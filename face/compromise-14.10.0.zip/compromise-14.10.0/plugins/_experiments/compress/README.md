they say that compression and intellegence are the same thing,
but I'm not small-enough to understand that.

