attempt to create a [unist-formatted](https://github.com/syntax-tree/unist) Abstract Syntax Tree via some [dependency parsing](http://nlpprogress.com/english/dependency_parsing.html)
