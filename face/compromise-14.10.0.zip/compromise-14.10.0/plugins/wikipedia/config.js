export default {
  lang: 'en',
  project: 'wikipedia',
  // min_pageviews: 3 // remove 378,151
  min_pageviews: 200 // remove 1,159,783
  // fresh: true, //start fresh
}
