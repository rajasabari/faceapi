// import download from './01-download.js'
import filter from './02-filter.js'
import compress from './03-compress.js'

// await download()
filter()
compress()