export default [
  'weekday',

  'summer',
  'winter',
  'autumn',

  // 'some day',
  // 'one day',
  'all day',
  // 'some point',

  'eod',
  'eom',
  'eoy',
  'standard time',
  'daylight time',
  'tommorrow',
]
