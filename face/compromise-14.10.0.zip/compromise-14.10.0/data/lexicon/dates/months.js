export default [
  // 'january',
  'february',
  // 'april',
  // 'june',
  'july',
  // 'august',
  'september',
  'october',
  'november',
  'december',
  //abbreviations are elsewhere
]
