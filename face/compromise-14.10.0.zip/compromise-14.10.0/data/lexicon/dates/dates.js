// uncontroversial date words
export default ['today',
  'tomorrow',
  'tmr',
  'tmrw',
  'yesterday',
  'weekend',
  'weekends',
  'week end',
  'ago',
  'q1',
  'q2',
  'q3',
  'q4',
  'someday',
  'oneday'
]
