export default [
  'lieutenant general',
  'field marshal',
  'rear admiral',
  'vice admiral',
  'sergeant major',
  'director general',
]