// person-names that can be dates
export default [
  // clues: [person, date],
  // fallback: 'Month',
  'april', 'august', 'jan', 'january', 'june', 'sep', 'avril',
  // 'may'
]

