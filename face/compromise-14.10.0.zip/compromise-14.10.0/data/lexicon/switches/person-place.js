// cities
export default [
  'alexandria',
  'austin',
  'darwin',
  'hamilton',
  'houston',
  'jordan',
  'kent',
  'kobe',
  'orlando',
  'salvador',
  'samara',
  'santiago',
  'sydney',
  'victoria',
]