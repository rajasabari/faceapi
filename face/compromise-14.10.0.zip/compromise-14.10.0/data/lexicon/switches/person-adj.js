export default [
  'misty',
  'rusty',
  'dusty',
  'rich',
  'randy',
  'sandy',
  'earnest',
  'frank',
  // 'young',
  'brown'
]