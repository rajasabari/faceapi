// properNouns
export default [
  'mercedes',
  'barbie',
  'catalina',
  'christi',
  'diego',
  'elmo',
  'franco',
  'kirby',
  'mickey',
  'finn',
  'missy',
  'florence',
  'stevens',
  // currencies
  'nis',
  'riel',
  'euro',
  'iron maiden',
]