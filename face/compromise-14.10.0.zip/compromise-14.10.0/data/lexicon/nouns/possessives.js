export default [
  // 'her', //this one is check ambiguous
  // 'hers',
  // 'his',
  'its',
  'mine',
  'my',
  // 'none',
  'our',
  'ours',
  'thy',
  // 'their',
  // 'theirs',
  // 'your',
  // 'yours',


]
