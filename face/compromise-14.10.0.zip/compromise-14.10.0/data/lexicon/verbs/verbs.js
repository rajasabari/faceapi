//verbs we shouldn't conjugate, for whatever reason
export default [
  'has',
  'keep tabs',
  'born',
  'cannot',
  'gonna',
  'msg',
  'make sure',

]
