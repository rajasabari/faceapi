export default [
  'can',
  'could',
  'lets', //arguable
  // 'may',
  'might',
  'must',
  'ought to',
  'ought',
  'oughta',
  'shall',
  'shant',
  'should',
  'will',
  'would',
]
