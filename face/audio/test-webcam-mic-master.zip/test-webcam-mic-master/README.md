# test-webcam-mic
HTML, JavaScript based webcam and microphone testing purely on the client side

https://sunil3590.github.io/test-webcam-mic/
